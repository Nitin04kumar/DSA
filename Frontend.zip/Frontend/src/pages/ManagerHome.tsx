import { useState } from 'react';
import Header from '../components/Hotel_&_Room_Management/Home Page/Header/Header';
import Sidebar from '../components/Hotel_&_Room_Management/Home Page/SideBar/Sidebar';
import ProfileForm from '../components/Hotel_&_Room_Management/Home Page/Header/ProfileForm';

import '../components/Hotel_&_Room_Management/Home Page/Home.css';
function ManagerHome() {
  const [showProfileForm, setShowProfileForm] = useState(false);

  return (
    <div className="app-container">
      <Header onProfileClick={() => setShowProfileForm(true)} />
      <div className="main-content">
        <Sidebar />
        <div className="content-frame">
          
        </div>
      </div>
      {showProfileForm && <ProfileForm onClose={() => setShowProfileForm(false)} />}
    </div>
  );
}

export default ManagerHome;
