import React, { useEffect, useState } from 'react';

interface Manager {
  name: string;
  email: string;
  contactNumber: string;
  role: string;
}

const AdminDashboard: React.FC = () => {
  const [managers, setManagers] = useState<Manager[]>([]);

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const managerList = users.filter((user: Manager) => user.role === 'manager');
    setManagers(managerList);
  }, []);

  return (
    <div className="dashboard admin-dashboard">
      <h2>Admin Dashboard</h2>
      <h3>Hotel Managers</h3>
      <ul className="user-list">
        {managers.map((manager, index) => (
          <li key={index} className="user-card">
            <p><strong>Name:</strong> {manager.name}</p>
            <p><strong>Email:</strong> {manager.email}</p>
            <p><strong>Contact:</strong> {manager.contactNumber}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;
