import React from 'react';

const UserHome: React.FC = () => {
  return (
    <div style={{ padding: '20px', backgroundColor: '#e0f7fa' }}>
      <h1>Hello from UserHome!</h1>
    </div>
  );
};

export default UserHome;
