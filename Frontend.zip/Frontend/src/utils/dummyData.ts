export type Hotel = {
  id: string;
  name: string;
  location: string;
  managerId: string;
  amenities: string[];
  rating: number;
};

export const sampleHotel: Hotel = {
  id: '1',
  name: 'Sample Hotel',
  location: 'Hyderabad',
  managerId: 'manager123',
  amenities: ['WiFi', 'Pool', 'Gym'],
  rating: 4.5,
};
