import React, { useState } from 'react';
import type { ChangeEvent } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/register.css';

interface Manager {
  name: string;
  contact: string;
  email: string;
  password: string;
  role: 'manager';
}

const RegisterManager: React.FC = () => {
  const [form, setForm] = useState<Manager>({
    name: '',
    contact: '',
    email: '',
    password: '',
    role: 'manager',
  });

  const navigate = useNavigate();

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch('/mock-api/managers.json');
      const managers: Manager[] = await response.json();

      const emailExists = managers.some(manager => manager.email === form.email);
      if (emailExists) {
        alert('Email already registered!');
        return;
      }

      // Simulate successful registration
      alert('Manager registered successfully!');
      navigate('/manager');
    } catch (error) {
      console.error('Error fetching managers:', error);
      alert('Something went wrong. Please try again later.');
    }
  };

  return (
    <div className="register-wrapper">
      <form className="register-form" onSubmit={handleSubmit}>
        <h2 className="register-title">Manager Registration</h2>
        <input
          className="register-input"
          name="name"
          placeholder="Name"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="contact"
          placeholder="Contact"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="email"
          placeholder="Email"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="password"
          type="password"
          placeholder="Password"
          onChange={handleChange}
          required
        />
        <button className="register-button" type="submit">Register</button>
      </form>
    </div>
  );
};

export default RegisterManager;
