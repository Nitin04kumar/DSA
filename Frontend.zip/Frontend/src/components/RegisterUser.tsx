import React, { useState } from 'react';
import type { ChangeEvent } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/register.css';

interface User {
  name: string;
  contact: string;
  email: string;
  password: string;
  role: 'guest' | 'manager' | 'admin';
}

const RegisterUser: React.FC = () => {
  const [form, setForm] = useState<Omit<User, 'role'> & { role: string }>({
    name: '',
    contact: '',
    email: '',
    password: '',
    role: '',
  });

  const navigate = useNavigate();

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    const newUser: User = {
      name: form.name,
      contact: form.contact,
      email: form.email,
      password: form.password,
      role: (form.role as User['role']) || 'guest',
    };

    try {
      const response = await fetch('/mock-api/users.json');
      const users: User[] = await response.json();

      const emailExists = users.some(user => user.email === newUser.email);
      if (emailExists) {
        alert('Email already registered!');
        return;
      }

      alert('User registered successfully!');
      navigate('/login');
    } catch (error) {
      console.error('Error fetching users:', error);
      alert('Something went wrong. Please try again later.');
    }
  };

  return (
    <div className="register-wrapper">
      <form className="register-form" onSubmit={handleSubmit}>
        <h2 className="register-title">User Registration</h2>
        <input
          className="register-input"
          name="name"
          placeholder="Name"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="contact"
          placeholder="Contact"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="email"
          placeholder="Email"
          onChange={handleChange}
          required
        />
        <input
          className="register-input"
          name="password"
          type="password"
          placeholder="Password"
          onChange={handleChange}
          required
        />
        <select
          className="register-input"
          name="role"
          onChange={handleChange}
          required
        >
          <option value="">Select Role</option>
          <option value="guest">Guest</option>
          <option value="manager">Hotel Manager</option>
          <option value="admin">Admin</option>
        </select>
        <button className="register-button" type="submit">Register</button>
      </form>
    </div>
  );
};

export default RegisterUser;
