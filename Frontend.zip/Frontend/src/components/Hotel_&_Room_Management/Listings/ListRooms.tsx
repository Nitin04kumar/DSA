import React, { useEffect, useState } from 'react';

interface Room {
  id: number;
  name: string;
  facilities: string[];
  price: number;
  isActive: boolean;
  images: string[];
}

const ListRooms: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([]);

  useEffect(() => {
    fetch('/api/rooms')
      .then((res) => res.json())
      .then((data) => setRooms(data))
      .catch((err) => console.error('Failed to fetch rooms:', err));
  }, []);

  const handleToggleRoom = async (id: number) => {
    try {
      const response = await fetch(`/api/rooms/${id}/toggle`, {
        method: 'PATCH',
      });

      if (response.ok) {
        setRooms((prevRooms) =>
          prevRooms.map((room) =>
            room.id === id ? { ...room, isActive: !room.isActive } : room
          )
        );
      }
    } catch (error) {
      console.error('Error toggling room:', error);
    }
  };

  return (
    <div className="room-listings">
      <h2>Room Listings</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Facilities</th>
            <th>Price / night</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rooms.map((room) => (
            <tr key={room.id}>
              <td>{room.name}</td>
              <td>{room.facilities.join(', ')}</td>
              <td>${room.price}</td>
              <td>
                <label className="switch">
                  <input
                    type="checkbox"
                    checked={room.isActive}
                    onChange={() => handleToggleRoom(room.id)}
                  />
                  <span className="slider round"></span>
                </label>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListRooms;