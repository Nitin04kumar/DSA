import React, { useState } from 'react';
import './AddHotel.css';
interface Hotel {
  name: string;
  location: string;
  description: string;
  imageFile: File | null;
}

const AddHotel: React.FC = () => {
  const [hotel, setHotel] = useState<Hotel>({
    name: '',
    location: '',
    description: '',
    imageFile: null,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setHotel({ ...hotel, [name]: value });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setHotel({ ...hotel, imageFile: e.target.files[0] });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Hotel submitted:', hotel);
    // Add API call here to save hotel data
  };

  return (
    <div className="add-hotel-form">
      <h2>Add New Hotel</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Hotel Name:
          <input type="text" name="name" value={hotel.name} onChange={handleChange} required />
        </label>
        <label>
          Location:
          <input type="text" name="location" value={hotel.location} onChange={handleChange} required />
        </label>
        <label>
          Description:
          <textarea name="description" value={hotel.description} onChange={handleChange} required />
        </label>
        <label className="upload-label">
          Upload Image:
          <input type="file" accept="image/*" onChange={handleImageUpload} />
        </label>
        <button type="submit">Add Hotel</button>
      </form>
    </div>
  );
};

export default AddHotel;
