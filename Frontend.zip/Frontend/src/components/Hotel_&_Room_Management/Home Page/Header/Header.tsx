import './Header.css'
interface HeaderProps {
  onProfileClick: () => void;
}

function Header({ onProfileClick }: HeaderProps) {
  return (
    <header className="header">
      <h1 className="title">Smart Hotel Management System</h1>
      <button className="profile-button" onClick={onProfileClick}>
        <img
          src="https://cdn-icons-png.flaticon.com/512/847/847969.png" // Replace with your actual image path
          alt="Profile"
          className="profile-icon"
        />
      </button>
    </header>
  );
}

export default Header;
