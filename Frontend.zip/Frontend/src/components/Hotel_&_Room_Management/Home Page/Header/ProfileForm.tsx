

interface ProfileFormProps {
  onClose: () => void;
}

function ProfileForm({ onClose }: ProfileFormProps) {
  return (
    <div className="profile-overlay">
      <div className="profile-form">
        <h2>Manager Details</h2>
        <form>
          {["Name", "Email", "Phone", "Password"].map((label, index) => (
            <div className="form-group" key={index}>
              <label>{label}:</label>
              <div className="input-with-icon">
                <input
                  type={label === "Email" ? "email" : label === "Phone" ? "tel" : "text"}
                  placeholder={`Enter ${label.toLowerCase()}`}
                />
                <span className="edit-icon" title="Edit">✏️</span>
              </div>
            </div>
          ))}
          <button type="button" className="close-button" onClick={onClose}>
            Close
          </button>
        </form>
      </div>
    </div>
  );
}

export default ProfileForm;
