import { Link, NavLink } from 'react-router-dom';
import './Sidebar.css';

function Sidebar() {
  return (
    <div>
      <h2>Manager</h2>
      <nav className="sidebar">
        <ul>
          <li><Link to="/addhotel">🏨 Add Hotel</Link></li>
          <li><NavLink to="/addroom">🛏️ Add Room</NavLink></li>
          <li><NavLink to="/listrooms">📋 List Rooms</NavLink></li>
          <li><NavLink to="/dashboard">🏠 Dashboard</NavLink></li>
        </ul>
      </nav>
    </div>
  );
}

export default Sidebar;
