import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './Header/Header';
import Sidebar from './SideBar/Sidebar';
import ProfileForm from './Header/ProfileForm';
import AddHotel from '../Hotels/AddHotel';
import AddRoom from '../Room/AddRoom';
import ListRooms from '../Listings/ListRooms';
import Dashboard from '../ManagerDashboard/Dashboard';
import '../Home Page/Home.css';

function Home() {
  const [showProfileForm, setShowProfileForm] = useState(false);

  return (
    <Router>
      <div className="app-container">
        <Header onProfileClick={() => setShowProfileForm(true)} />
        <div className="main-content">
          <Sidebar />
          <div className="content-frame">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/addhotel" element={<AddHotel />} />
              <Route path="/addroom" element={<AddRoom />} />
              <Route path="/listrooms" element={<ListRooms />} />
              <Route path="/dashboard" element={<Dashboard />} />
            </Routes>
          </div>
        </div>
        {showProfileForm && <ProfileForm onClose={() => setShowProfileForm(false)} />}
      </div>
    </Router>
  );
}

export default Home;
