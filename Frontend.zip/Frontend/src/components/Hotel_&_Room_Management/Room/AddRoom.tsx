
import React, { useState } from 'react'

const AddRoom: React.FC = () => {
  const [roomType, setRoomType] = useState('');
  const [price, setPrice] = useState(0);
  const [amenities, setAmenities] = useState<string[]>([]);
  const [images, setImages] = useState<File[]>([]);

  const handleAmenityChange = (amenity: string) => {
    setAmenities(prev =>
      prev.includes(amenity)
        ? prev.filter(a => a !== amenity)
        : [...prev, amenity]
    );
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setImages(Array.from(e.target.files));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const roomData = {
      name: roomType,
      price,
      facilities: amenities,
      isActive: true,
      images: images.map(file => file.name),
    };

    console.log('Simulated room data:', roomData);
    localStorage.setItem('roomData', JSON.stringify(roomData));

    alert('Room added successfully!');
    setRoomType('');
    setPrice(0);
    setAmenities([]);
    setImages([]);
  };

  return (
    <div className="add-room-container">
      <h2>Add Room</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Upload Room Images:</label>
          <input type="file" multiple accept="image/*" onChange={handleImageUpload} />
        </div>

        <div className="form-group">
          <label>Room Type:</label>
          <select value={roomType} onChange={e => setRoomType(e.target.value)} required>
            <option value="">Select Room Type</option>
            <option value="Single">Single</option>
            <option value="Double">Double</option>
            <option value="Suite">Suite</option>
          </select>
        </div>

        <div className="form-group">
          <label>Price /night:</label>
          <input
            type="number"
            value={price}
            onChange={e => setPrice(Number(e.target.value))}
            min="0"
            required
          />
        </div>

        <div className="form-group">
          <label>Amenities:</label>
          <div className="checkbox-group">
            {['Free WiFi', 'Free Breakfast', 'Room Service', 'Mountain View', 'Pool Access'].map(
              amenity => (
                <label key={amenity} className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={amenities.includes(amenity)}
                    onChange={() => handleAmenityChange(amenity)}
                  />
                  {amenity}
                </label>
              )
            )}
          </div>
        </div>

        <button type="submit" className="submit-button">Add Room</button>
      </form>
    </div>
  );
};

export default AddRoom;