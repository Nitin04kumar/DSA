import React, { useState } from 'react';
import type { FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/login.css';

interface User {
  email: string;
  password: string;
  role: 'user' | 'manager' | 'admin';
}

const Login: React.FC = () => {
  const [role, setRole] = useState<'user' | 'manager' | 'admin'>('user');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const navigate = useNavigate();

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch('/mock-api/login.json');
      const users: User[] = await response.json();

      const user = users.find(
        (u) => u.email === email && u.password === password && u.role === role
      );

      if (user) {
        alert('Login successful!');
        if (user.role === 'manager') {
          navigate('/manager');
        } else if (user.role === 'admin') {
          navigate('/admin');
        } else {
          navigate('/guest');
        }
      } else {
        alert('Invalid credentials');
      }
    } catch (error) {
      console.error('Error during login:', error);
      alert('Something went wrong. Please try again later.');
    }
  };

  return (
    <div className="login-page-wrapper">
      <form className="login-form-box" onSubmit={handleLogin}>
        <h2 className="login-form-title">Login</h2>
        <select
          className="login-form-input"
          onChange={(e) => setRole(e.target.value as 'user' | 'manager' | 'admin')}
          required
        >
          <option value="user">User</option>
          <option value="manager">Hotel Manager</option>
          <option value="admin">Admin</option>
        </select>
        <input
          className="login-form-input"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          className="login-form-input"
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button className="login-form-button" type="submit">Login</button>
        <div className="login-form-links">
          <p>New User? <a href="/register-user">Register Here</a></p>
          <p>Hotel Manager? <a href="/register-manager">Register Here</a></p>
        </div>
      </form>
    </div>
  );
};

export default Login;
