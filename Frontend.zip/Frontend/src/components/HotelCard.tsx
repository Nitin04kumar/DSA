import React from 'react';

// Define the shape of hotel data
export interface Hotel {
  id: string;
  name: string;
  location: string;
  managerId: string;
  amenities: string[];
  rating: number;
}

// Define props for the component
interface HotelCardProps {
  hotel: Hotel;
  onEdit?: () => void; // ✅ Optional edit handler
}

const HotelCard: React.FC<HotelCardProps> = ({ hotel, onEdit }) => {
  return (
    <div className="hotel-card">
      <h2>{hotel.name}</h2>
      <p><strong>Hotel ID:</strong> {hotel.id}</p>
      <p><strong>Location:</strong> {hotel.location}</p>
      <p><strong>Manager ID:</strong> {hotel.managerId}</p>
      <p><strong>Amenities:</strong> {hotel.amenities.join(', ')}</p>
      <p><strong>Rating:</strong> {hotel.rating}</p>
      {onEdit && <button onClick={onEdit}>Edit Hotel</button>}
    </div>
  );
};

export default HotelCard;
