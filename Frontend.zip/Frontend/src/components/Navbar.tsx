import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';

interface NavbarProps {
  isLoggedIn: boolean;
  setIsLoggedIn: (status: boolean) => void;
}

const Navbar: React.FC<NavbarProps> = ({ isLoggedIn, setIsLoggedIn }) => {
  const navigate = useNavigate();

  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate('/login'); // Redirect to login page
  };

  return (
    <nav className="navbar">
      <h2 className="logo">Smart Hotel</h2>
      <div className="nav-links">
        <Link to="/">Home</Link>
        {!isLoggedIn ? (
          <>
            <Link to="/login">Login</Link>
            <div className="dropdown">
              <button className="dropbtn">Register ▾</button>
              <div className="dropdown-content">
                <Link to="/register-user">As User</Link>
                <Link to="/register-manager">As Manager</Link>
              </div>
            </div>
          </>
        ) : (
          <button onClick={handleLogout}>Logout</button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
