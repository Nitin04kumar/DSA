import React from 'react';
import '../styles/home.css';

// Define the type for a hotel object
interface Hotel {
  name: string;
  location: string;
}

// Define props type for the component
interface HomePageProps {
  hotels: Hotel[];
}

const HomePage: React.FC<HomePageProps> = ({ hotels }) => (
  <div className="home-container">
    <h2>Welcome to Smart Hotel Management</h2>
    <div className="hotel-list">
      {hotels.length === 0 ? (
        <p>No hotels added yet.</p>
      ) : (
        hotels.map((hotel, index) => (
          <div key={index} className="hotel-card">
            <h3>{hotel.name}</h3>
            <p>{hotel.location}</p>
          </div>
        ))
      )}
    </div>
  </div>
);

export default HomePage;
