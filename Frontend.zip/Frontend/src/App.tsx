import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import Login from './components/Login';
import RegisterUser from './components/RegisterUser';
import RegisterManager from './components/RegisterManager';
import ManagerHome from './pages/ManagerHome';
import AdminDashboard from './pages/AdminDashboard';
import UserHome from './pages/UserHome';
import { sampleHotel } from './utils/dummyData';
import type { Hotel } from './utils/dummyData';


function App() {
  const [hotels] = useState<Hotel[]>([sampleHotel]);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);

  return (
    <>
      <Navbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />
      <Routes>
        <Route path="/" element={<HomePage hotels={hotels} />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register-user" element={<RegisterUser />} />
        <Route path="/register-manager" element={<RegisterManager />} />
        
        {/*
          This is the key change. We now have a single parent route for '/manager'.
          All the manager's sub-pages will be rendered within the ManagerHome component.
        */}
        <Route path="/manager/*" element={<ManagerHome />} />
        
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/guest" element={<UserHome />} />
      </Routes>
    </>
  );
}

export default App;